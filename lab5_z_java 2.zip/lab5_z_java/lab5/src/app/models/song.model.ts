export interface Song {
  id: string;
  name: string;
  length: number;
}
