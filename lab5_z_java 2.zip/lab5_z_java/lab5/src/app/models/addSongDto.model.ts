export interface addSongDto {
  name: string;
  length: number;
}
